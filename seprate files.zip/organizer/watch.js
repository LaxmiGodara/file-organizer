import fs from "fs";
import { downloadsPath } from "../config/paths.js";
import { processFile } from "./processFile.js";

export function watchDownloads(isDryRun) {
  fs.watch(downloadsPath, (eventType, filename) => {
    if (!filename) return;

    setTimeout(() => {
      processFile(filename, isDryRun);
    }, 3000);
  });
}
