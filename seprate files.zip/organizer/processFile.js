import fs from "fs";
import path from "path";
import { moveFileWithRetry } from "../utils/retryMove.js";
import { downloadsPath } from "../config/paths.js";

const processingFiles = new Set();

const configPath = path.join(process.cwd(), "config.json");
const config = JSON.parse(fs.readFileSync(configPath, "utf-8"));

// CORE FILE PROCESSING LOGIC

export function processFile(filename , isDryRun) {

    
  const sourcePath = path.join(downloadsPath, filename);

  fs.stat(sourcePath, (err, stats) => {
    // Temporary issues → ignore silently
    if (err) return;

    // Ignore folders
    if (stats.isDirectory()) return;

    // Ignore unstable files
    if (stats.size === 0) return;

    const extension = path.extname(filename).toLowerCase();

    let category = null;

    // Find matching category from config
    for (const key in config) {
      if (config[key].includes(extension)) {
        category = key;
        break;
      }
    }

    // Ignore unknown types
    if (!category) return;

    const destinationDir = path.join(downloadsPath, category);
    const destinationPath = path.join(destinationDir, filename);

    // Skip if already organized
    if (sourcePath === destinationPath) return;

    console.log(`Preparing: ${filename} → ${category}/`);

    // Ensure destination folder exists
    fs.mkdir(destinationDir, { recursive: true }, (mkdirErr) => {
      if (mkdirErr) {
        logError(`FAILED to create folder ${category}`);
        return;
      }

      moveFileWithRetry(sourcePath, destinationPath, filename);
    });
  });
}
